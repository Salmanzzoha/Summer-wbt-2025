<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<?php include("header.php"); ?>
<div class="sidebar">
    <a href="dashboard.php">Dashboard</a><br>
    <a href="view_profile.php">View Profile</a><br>
    <a href="edit_profile.php">Edit Profile</a><br>
    <a href="profile_picture.php">Change Profile Picture</a><br>
    <a href="change_password.php">Change Password</a><br>
    <a href="logout.php">Logout</a>
</div>

<div class="content with-sidebar">
    <h3>PROFILE PICTURE</h3>
    
    
    <img src="images/profilelogo.jpeg" alt="Profile Picture" class="profile-pic"><br><br>
    
    
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="profile_pic"><br><br>
        <input type="submit" value="Submit">
    </form>
</div>
<?php include("footer.php"); ?>