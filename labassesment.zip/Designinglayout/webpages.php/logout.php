<?php include("header.php"); ?>
<div class="content">
    <h3>You have been logged out.</h3>
    <a href="login.php">Login Again</a>
</div>
<?php include("footer.php"); ?>