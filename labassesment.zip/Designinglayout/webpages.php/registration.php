<?php include("header.php"); ?>
<h3>REGISTRATION</h3>
<form>
    Name: <input type="text"><br><br>
    Email: <input type="email"><br><br>
    User Name: <input type="text"><br><br>
    Password: <input type="password"><br><br>
    Confirm Password: <input type="password"><br><br>
    Gender: 
    <input type="radio" name="gender"> Male
    <input type="radio" name="gender"> Female
    <input type="radio" name="gender"> Other <br><br>
    Date of Birth: <input type="date"><br><br>
    <input type="submit" value="Submit">
    <input type="reset" value="Reset">
</form>
<?php include("footer.php"); ?>