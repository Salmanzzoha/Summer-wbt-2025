<?php include("header.php"); ?>
<h3>FORGOT PASSWORD</h3>
<form>
    Enter Email: <input type="email"><br><br>
    <input type="submit" value="Submit">
</form>
<?php include("footer.php"); ?>