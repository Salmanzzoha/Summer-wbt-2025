<?php include("header.php"); ?>
<div class="sidebar">
    <a href="dashboard.php">Dashboard</a><br>
    <a href="view_profile.php">View Profile</a><br>
    <a href="edit_profile.php">Edit Profile</a><br>
    <a href="profile_picture.php">Change Profile Picture</a><br>
    <a href="change_password.php">Change Password</a><br>
    <a href="logout.php">Logout</a>
</div>
<div class="content">
    <h3>EDIT PROFILE</h3>
    <form>
        Name: <input type="text" value="Bob"><br><br>
        Email: <input type="email" value="bob@aiub.edu"><br><br>
        Gender: <input type="radio" name="gender" checked> Male 
                <input type="radio" name="gender"> Female
                <input type="radio" name="gender"> Other <br><br>
        Date of Birth: <input type="date" value="1998-09-19"><br><br>
        <input type="submit" value="Submit">
    </form>
</div>
<?php include("footer.php"); ?>