<?php include("header.php"); ?>
<h3>LOGIN</h3>
<form>
    User Name: <input type="text"><br><br>
    Password: <input type="password"><br><br>
    <input type="checkbox"> Remember Me <br><br>
    <input type="submit" value="Submit"> 
    <a href="forgot_password.php">Forgot Password?</a>
</form>
<?php include("footer.php"); ?>