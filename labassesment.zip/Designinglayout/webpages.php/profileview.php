<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<?php include("header.php"); ?>
<div class="sidebar">
    <a href="dashboard.php">Dashboard</a><br>
    <a href="view_profile.php">View Profile</a><br>
    <a href="edit_profile.php">Edit Profile</a><br>
    <a href="profile_picture.php">Change Profile Picture</a><br>
    <a href="change_password.php">Change Password</a><br>
    <a href="logout.php">Logout</a>
</div>

<div class="content with-sidebar">
    <h3>PROFILE</h3>
    Name: Bob <br>
    Email: bob@aiub.edu <br>
    Gender: Male <br>
    Date of Birth: 19/09/1998 <br><br>
    
   
    <img src="images/profilelogo.jpeg" alt="Profile Picture" class="profile-pic"><br><br>
    
    <a href="edit_profile.php">Edit Profile</a>
</div>
<?php include("footer.php"); ?>