<!DOCTYPE html>
<html>
<head>
    <title>xCompany</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <div class="logo"> <b style="color:green;">X</b>Company </div>
        <div class="menu">
            <a href="index.php">Home</a> |
            <a href="login.php">Login</a> |
            <a href="registration.php">Registration</a>
        </div>
    </div>
    <hr>